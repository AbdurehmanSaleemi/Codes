#include <iostream>
using namespace std;

int** AllocateMemory(int& rows, int& cols)
{
    int** dp = new int* [rows];

    for (int i = 0; i < rows; i++)
    {
        dp[i] = new int[cols];
    }
    return dp;
}

void InputMatrix(int** dp, const int rows, const int cols)
{
    int** endptr = dp + rows;

    for (int** i = dp ; i < endptr; i++)
    {
        int* endCol = *(i) + cols;
        for (int* j = *i; j < endCol; j++)
        {
            cin >> *j;
        }
    }
}

void DisplayMatrix(int** dp, int rows, int cols)
{
    int** endptr = dp+rows;
    for (int** i = dp; i < endptr; i++)
    {
        int* endOfCols = *(i) + cols;
        for (int *j = *i; j < endOfCols; j++)
        {
            cout << *j << " ";
        }
        cout << endl;
    }
}

void deallocateMemory(int**& memory, int rows)
{
    for (int i = 0; i < rows; i++)
    {
        delete [] memory[i];
    }
    delete [] memory;
    memory = nullptr;
}

int main(){
    int rows = 3;
    int cols = 3;
    //take input from user for rows and cols
    int ** matrix = AllocateMemory(rows,cols);
    InputMatrix(matrix, rows, cols);
    DisplayMatrix(matrix, rows, cols);
    maxVal(matrix, rows, cols);
    //deallocate matrix
    deallocateMemory(matrix, rows);
    //delete maxColValues
    return 0;
}